<?php
function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $cfg = require __DIR__ . '/config.php';
    foreach (['db_host','db_name','db_user'] as $key) {
        if (empty($cfg[$key]) || str_starts_with($cfg[$key], 'YOUR_')) {
            throw new RuntimeException('Database settings are not configured. Edit config.php first.');
        }
    }
    $dsn = 'mysql:host='.$cfg['db_host'].';dbname='.$cfg['db_name'].';charset=utf8mb4';
    $pdo = new PDO($dsn, $cfg['db_user'], $cfg['db_pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

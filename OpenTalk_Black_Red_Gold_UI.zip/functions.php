<?php
require_once __DIR__ . '/db.php';
function start_app_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('private_chat_session');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function current_user(): ?array {
    start_app_session();
    if (empty($_SESSION['user_id'])) return null;
    $stmt = db()->prepare('SELECT id, username, role, is_active FROM users WHERE id=? LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $u = $stmt->fetch();
    if (!$u || !(int)$u['is_active']) { $_SESSION = []; session_destroy(); return null; }
    return $u;
}
function require_login(): array {
    $u = current_user();
    if (!$u) json_response(['ok'=>false,'error'=>'Please log in again.'],401);
    return $u;
}
function require_admin_page(): array {
    $u = current_user();
    if (!$u || $u['role'] !== 'admin') { header('Location: login.php'); exit; }
    return $u;
}
function csrf_token(): string {
    start_app_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    start_app_session();
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');
    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) json_response(['ok'=>false,'error'=>'Security token expired. Refresh the page.'],403);
}
function json_response(array $data, int $status=200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function request_data(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    return is_array($data) ? $data : $_POST;
}
function clean_text($value, int $max=2000): string {
    $value = trim((string)$value);
    if (function_exists('mb_strlen') && mb_strlen($value) > $max) $value = mb_substr($value, 0, $max);
    elseif (strlen($value) > ($max * 4)) $value = substr($value, 0, $max * 4);
    return $value;
}
function app_config(): array { return require __DIR__ . '/config.php'; }

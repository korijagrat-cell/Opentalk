PRIVATE CHAT - INFINITYFREE PHP + MYSQL EDITION
================================================

FEATURES INCLUDED
- Private login; there is no public sign-up page.
- First admin account is created once through install.php.
- Admin can create users, enable/disable users, and reset user passwords.
- One shared General room for all active accounts.
- Messages are saved in your own MySQL database.
- Browser polling refreshes chat messages approximately every 3 seconds.
- Online-member list uses a heartbeat (online status is approximate).
- One-to-one voice-call UI and WebRTC offer/answer/ICE signaling through PHP requests.
- No Firebase, Supabase, hosted chat API, external JavaScript library, or external font.

IMPORTANT HOSTING LIMITATIONS
- InfinityFree does not support Node.js or WebSockets. This version uses normal browser HTTP requests and PHP.
- InfinityFree free hosting has resource/usage restrictions and is not intended as a general API or application-server platform. Frequent polling by many users may hit resource limits or host restrictions. Test with a small number of users first and review current InfinityFree terms/support guidance.
- This is a small MVP, not a high-scale chat server.
- Voice calls use browser WebRTC. This package has no external STUN/TURN dependency by default (ice_servers is empty in config.php). Calls may work on some networks, especially the same LAN, but direct connections across mobile networks/routers are NOT guaranteed. Reliable cross-network calls generally need STUN/TURN infrastructure. For full control, operate your own STUN/TURN server (for example, coturn) on a separate VPS and add its ICE details to config.php. InfinityFree itself cannot host that server.
- Microphone access requires HTTPS (or localhost during local development). Enable SSL before testing calls.
- No end-to-end encryption: chat messages and call signaling are stored in the MySQL database. Use HTTPS and strong passwords. Do not use this MVP for sensitive conversations.
- There are no private DMs, multiple rooms, group voice calls, file uploads, password self-service, or message edit/delete in this first version. The discussed shared room, admin-created accounts, group messaging and one-to-one voice call flow are included.

INSTALL ON INFINITYFREE
1. In the InfinityFree client area, create a hosting account/domain and open its Control Panel.
2. Open MySQL Databases and create a database and database user if the panel asks for it.
3. Copy the exact MySQL host, database name, username and password shown there.
4. Open this package's config.php and replace:
     YOUR_MYSQL_HOST
     YOUR_DATABASE_NAME
     YOUR_DATABASE_USERNAME
     YOUR_DATABASE_PASSWORD
   Do not put quotes inside the values; keep the existing PHP quote marks.
5. Open phpMyAdmin from the hosting Control Panel, select the database you created, choose Import, and upload schema.sql from this package.
6. Open File Manager (or FTP) and upload the CONTENTS of this folder into your website's htdocs directory. The public folder must remain a folder. index.php should be directly inside htdocs.
7. Visit https://YOUR-DOMAIN/install.php . Create the first admin login ID and a strong password (12+ characters).
8. IMPORTANT: After the admin account is created, delete install.php from htdocs using File Manager/FTP.
9. Visit https://YOUR-DOMAIN/login.php and sign in. Open Admin to create member accounts.
10. Test with two separate browsers/devices. Both users sign in using accounts created by the admin.

FOLDER LAYOUT
config.php        MySQL connection settings and app options
.htaccess         Blocks direct access to sensitive config/schema files
schema.sql        Database tables; import this through phpMyAdmin
install.php       One-time first-admin setup; delete after installation
login.php         Login page
logout.php        Logout
index.php         Main shared chat page
admin.php         Admin account management
api.php           Internal browser-request handlers for chat/presence/calls
db.php            PDO database connection
functions.php     Sessions, authentication, CSRF and helper functions
public/style.css  Styles
public/app.js     Browser chat polling and WebRTC client

TROUBLESHOOTING
- Database connection error: check all four values in config.php. InfinityFree's MySQL host is usually NOT localhost; use the exact host shown in the panel.
- Table missing: import schema.sql into the correct database using phpMyAdmin.
- HTTP 500: check PHP error logs if available; temporarily inspect the host's PHP error display/logging settings. Do not leave detailed errors publicly enabled.
- 403 on API calls: confirm the site is loaded over the same domain, login session is active, and JavaScript requests are coming from the browser page.
- Messages not updating: confirm JavaScript is enabled, api.php is uploaded, and the database has the messages table.
- Voice call button not working: use HTTPS, allow microphone access, and test two users. If both devices are on different networks, an own STUN/TURN server may be required.

SECURITY NOTES
- Passwords are stored as password hashes, not plaintext.
- SQL uses prepared statements.
- Browser POST requests require a CSRF token.
- Session cookies are HttpOnly and SameSite=Lax; Secure is enabled when HTTPS is detected.
- Keep config.php private and never share database credentials.
- Back up the MySQL database and source files regularly.

This source is provided as a starter project and has not undergone an independent security audit.

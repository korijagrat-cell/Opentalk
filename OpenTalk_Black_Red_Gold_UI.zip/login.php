<?php
require_once __DIR__ . '/functions.php';
start_app_session();
if (current_user()) { header('Location: index.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username=trim($_POST['username']??''); $password=$_POST['password']??'';
    $stmt=db()->prepare('SELECT id,password_hash,is_active FROM users WHERE username=? LIMIT 1'); $stmt->execute([$username]); $u=$stmt->fetch();
    if ($u && (int)$u['is_active']===1 && password_verify($password,$u['password_hash'])) {
        session_regenerate_id(true); $_SESSION['user_id']=(int)$u['id']; $_SESSION['csrf']=bin2hex(random_bytes(32));
        db()->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$u['id']]); header('Location: index.php'); exit;
    }
    $error='Login ID or password is incorrect, or this account is disabled.';
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login · Private Chat</title><link rel="stylesheet" href="public/style.css"></head><body class="auth-body"><main class="auth-card"><div class="brand-mark">PC</div><h1>Welcome back</h1><p class="muted">Sign in with the account created by your administrator.</p><?php if($error): ?><div class="alert"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?>
<form method="post">
<label>Login ID</label><input name="username" required autocomplete="username">
<label>Password</label><input type="password" name="password" required autocomplete="current-password">
<button class="primary full" type="submit">Sign in to OpenTalk</button>
</form>
<p class="tiny">Accounts are created by the administrator. There is no public registration.</p>
</main></body></html>

<?php
require_once __DIR__ . '/functions.php';
$me=require_login();
if ($_SERVER['REQUEST_METHOD'] !== 'GET') verify_csrf();
$action=$_GET['action'] ?? '';
$pdo=db();
try {
 switch ($action) {
  case 'messages':
    $after=max(0,(int)($_GET['after']??0));
    if ($after===0) { $rows=$pdo->query('SELECT m.id,m.user_id,u.username,m.body,UNIX_TIMESTAMP(m.created_at) created_at FROM (SELECT * FROM messages ORDER BY id DESC LIMIT 60) m JOIN users u ON u.id=m.user_id ORDER BY m.id ASC')->fetchAll(); }
    else { $s=$pdo->prepare('SELECT m.id,m.user_id,u.username,m.body,UNIX_TIMESTAMP(m.created_at) created_at FROM messages m JOIN users u ON u.id=m.user_id WHERE m.id>? ORDER BY m.id ASC LIMIT 100'); $s->execute([$after]); $rows=$s->fetchAll(); }
    json_response(['ok'=>true,'messages'=>$rows]);
  case 'send_message':
    $d=request_data(); $body=clean_text($d['body']??'',2000);
    if ($body==='') json_response(['ok'=>false,'error'=>'Write a message first.'],422);
    $s=$pdo->prepare('SELECT last_message_at FROM users WHERE id=?'); $s->execute([$me['id']]); $last=$s->fetchColumn();
    if ($last && (time()-strtotime($last))<1) json_response(['ok'=>false,'error'=>'Please wait a moment before sending again.'],429);
    $s=$pdo->prepare('INSERT INTO messages(user_id,body) VALUES(?,?)'); $s->execute([$me['id'],$body]);
    $pdo->prepare('UPDATE users SET last_message_at=NOW(),last_seen=NOW() WHERE id=?')->execute([$me['id']]);
    json_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()]);
  case 'heartbeat':
    $pdo->prepare('UPDATE users SET last_seen=NOW() WHERE id=?')->execute([$me['id']]);
    $timeout=max(10,min(300,(int)(app_config()['presence_timeout_seconds']??60)));
    $s=$pdo->query('SELECT id,username FROM users WHERE is_active=1 AND last_seen >= DATE_SUB(NOW(), INTERVAL '.$timeout.' SECOND) ORDER BY username');
    json_response(['ok'=>true,'users'=>$s->fetchAll()]);
  case 'call_start':
    $d=request_data(); $to=(int)($d['to_user_id']??0); $offer=$d['offer']??null;
    if (!$to || $to===(int)$me['id'] || !is_array($offer)) json_response(['ok'=>false,'error'=>'Invalid call request.'],422);
    $s=$pdo->prepare('SELECT id,username FROM users WHERE id=? AND is_active=1'); $s->execute([$to]); $target=$s->fetch();
    if (!$target) json_response(['ok'=>false,'error'=>'User is not available.'],404);
    $s=$pdo->prepare("SELECT id FROM calls WHERE status IN ('ringing','accepted') AND (from_user_id=? OR to_user_id=? OR from_user_id=? OR to_user_id=?) LIMIT 1"); $s->execute([$me['id'],$me['id'],$to,$to]);
    if ($s->fetch()) json_response(['ok'=>false,'error'=>'One of the users is already in a call.'],409);
    $callId=bin2hex(random_bytes(16));
    $pdo->prepare("INSERT INTO calls(id,from_user_id,to_user_id,status) VALUES(?,?,?,'ringing')")->execute([$callId,$me['id'],$to]);
    $pdo->prepare("INSERT INTO call_signals(call_id,from_user_id,to_user_id,signal_type,payload) VALUES(?,?,?,'offer',?)")->execute([$callId,$me['id'],$to,json_encode($offer)]);
    json_response(['ok'=>true,'call_id'=>$callId,'target_name'=>$target['username']]);
  case 'call_poll':
    $after=max(0,(int)($_GET['after']??0));
    $s=$pdo->prepare("SELECT c.id,c.from_user_id,c.to_user_id,c.status,u.username from_name FROM calls c JOIN users u ON u.id=c.from_user_id WHERE c.to_user_id=? AND c.status='ringing' ORDER BY c.created_at DESC LIMIT 3"); $s->execute([$me['id']]); $incoming=$s->fetchAll();
    $s=$pdo->prepare("SELECT id,call_id,from_user_id,signal_type,payload FROM call_signals WHERE to_user_id=? AND id>? ORDER BY id ASC LIMIT 100"); $s->execute([$me['id'],$after]); $signals=$s->fetchAll();
    foreach($signals as &$sig) { $sig['id']=(int)$sig['id']; $sig['payload']=$sig['payload']?json_decode($sig['payload'],true):null; } unset($sig);
    $s=$pdo->prepare("SELECT c.id,c.from_user_id,c.to_user_id,c.status,IF(c.from_user_id=?,u2.username,u1.username) other_name FROM calls c JOIN users u1 ON u1.id=c.from_user_id JOIN users u2 ON u2.id=c.to_user_id WHERE (c.from_user_id=? OR c.to_user_id=?) AND c.status IN ('ringing','accepted') ORDER BY c.created_at DESC LIMIT 1"); $s->execute([$me['id'],$me['id'],$me['id']]); $active=$s->fetch() ?: null;
    json_response(['ok'=>true,'incoming'=>$incoming,'signals'=>$signals,'active_call'=>$active]);
  case 'call_signal':
    $d=request_data(); $callId=preg_replace('/[^a-f0-9]/','',(string)($d['call_id']??'')); $type=$d['type']??''; $payload=$d['payload']??null;
    if (!in_array($type,['answer','ice','hangup','decline'],true) || strlen($callId)!==32) json_response(['ok'=>false,'error'=>'Invalid call signal.'],422);
    $s=$pdo->prepare("SELECT * FROM calls WHERE id=? AND (from_user_id=? OR to_user_id=?) AND status IN ('ringing','accepted')"); $s->execute([$callId,$me['id'],$me['id']]); $call=$s->fetch();
    if (!$call) json_response(['ok'=>false,'error'=>'Call has ended.'],404);
    $other=((int)$call['from_user_id']===(int)$me['id'])?(int)$call['to_user_id']:(int)$call['from_user_id'];
    if ($type==='answer') $pdo->prepare("UPDATE calls SET status='accepted' WHERE id=?")->execute([$callId]);
    if ($type==='hangup' || $type==='decline') $pdo->prepare("UPDATE calls SET status=? WHERE id=?")->execute([$type==='decline'?'declined':'ended',$callId]);
    $payloadJson=$payload===null?null:json_encode($payload);
    $pdo->prepare('INSERT INTO call_signals(call_id,from_user_id,to_user_id,signal_type,payload) VALUES(?,?,?,?,?)')->execute([$callId,$me['id'],$other,$type,$payloadJson]);
    json_response(['ok'=>true]);
  default: json_response(['ok'=>false,'error'=>'Unknown action.'],404);
 }
} catch (Throwable $e) {
 error_log('Private Chat API error: '.$e->getMessage());
 json_response(['ok'=>false,'error'=>'A server error occurred. Check your database setup and try again.'],500);
}

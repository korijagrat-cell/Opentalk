<?php
// Add the exact MySQL details shown in your InfinityFree Control Panel.
// Do not share this file publicly. The .htaccess file blocks direct access.
return [
    'db_host' => 'YOUR_MYSQL_HOST',
    'db_name' => 'YOUR_DATABASE_NAME',
    'db_user' => 'YOUR_DATABASE_USERNAME',
    'db_pass' => 'YOUR_DATABASE_PASSWORD',
    'app_name' => 'OpenTalk',
    'poll_interval_ms' => 3000,
    'presence_timeout_seconds' => 60,
    // Leave empty for no external ICE dependency. Add your own STUN/TURN server later if needed.
    'ice_servers' => [],
];

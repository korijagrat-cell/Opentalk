<?php
require_once __DIR__ . '/functions.php';
start_app_session();
$error = '';
try {
    $count = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    if ($count > 0) { http_response_code(403); exit('Installation is already complete. Delete install.php from hosting.'); }
} catch (Throwable $e) { $error = 'Database is not ready. Check config.php and import schema.sql using phpMyAdmin. Details: '.$e->getMessage(); }
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $username = trim($_POST['username'] ?? ''); $password = $_POST['password'] ?? '';
    if (!preg_match('/^[a-zA-Z0-9_.-]{3,40}$/', $username)) $error = 'Admin ID must be 3–40 characters (letters, numbers, dot, underscore or dash).';
    elseif (strlen($password) < 12) $error = 'Use an admin password with at least 12 characters.';
    else {
        $stmt = db()->prepare("INSERT INTO users (username,password_hash,role) VALUES (?,?,'admin')");
        $stmt->execute([$username,password_hash($password,PASSWORD_DEFAULT)]);
        session_regenerate_id(true); $_SESSION['user_id'] = (int)db()->lastInsertId(); $_SESSION['csrf'] = bin2hex(random_bytes(32));
        header('Location: index.php'); exit;
    }
}
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Install OpenTalk</title><link rel="stylesheet" href="public/style.css"></head><body class="auth-body"><main class="auth-card"><div class="brand-mark">OT</div><h1>Set up your admin</h1><p class="muted">Create the first administrator account. Public sign-up is not available.</p><?php if($error): ?><div class="alert"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?><form method="post"><label>Admin login ID</label><input name="username" required minlength="3" maxlength="40" autocomplete="username"><label>Strong password</label><input type="password" name="password" required minlength="12" autocomplete="new-password"><button class="primary full" type="submit">Create admin account</button></form><p class="tiny">After setup, delete install.php from your hosting File Manager.</p></main></body></html>

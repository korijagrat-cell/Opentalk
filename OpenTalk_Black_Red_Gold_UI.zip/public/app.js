(() => {
  'use strict';
  const cfg = window.CHAT_CONFIG;
  const $ = (id) => document.getElementById(id);
  const messageList = $('message-list'), messageInput = $('message-input'), notice = $('notice');
  let lastMessageId = 0, lastSignalId = 0, onlineUsers = [], pc = null, currentCallId = null;
  let currentCallPeer = null, pendingOffer = null, callPollBusy = false, queuedLocalIce = [], queuedRemoteIce = [], localStream = null;
  const api = async (action, data = null, method = 'GET', extra = '') => {
    const opts = { method, credentials: 'same-origin', headers: {} };
    let url = `api.php?action=${encodeURIComponent(action)}${extra}`;
    if (method === 'POST') { opts.headers['Content-Type'] = 'application/json'; opts.headers['X-CSRF-Token'] = cfg.csrf; opts.body = JSON.stringify(data || {}); }
    const response = await fetch(url, opts);
    let result; try { result = await response.json(); } catch { throw new Error('Server returned an invalid response. Check the PHP setup.'); }
    if (!response.ok || !result.ok) throw new Error(result.error || 'Request failed.');
    return result;
  };
  const showNotice = (text, bad = false) => { notice.textContent = text; notice.classList.toggle('bad', bad); notice.classList.add('visible'); clearTimeout(showNotice.timer); showNotice.timer = setTimeout(() => notice.classList.remove('visible'), 4200); };
  const timeLabel = (unix) => new Date(Number(unix) * 1000).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  const addMessage = (m) => {
    if (messageList.querySelector('.empty-state')) messageList.innerHTML = '';
    const row = document.createElement('article'); row.className = 'message-row' + (Number(m.user_id) === cfg.userId ? ' mine' : '');
    const avatar = document.createElement('div'); avatar.className = 'avatar'; avatar.textContent = String(m.username).slice(0,1).toUpperCase();
    const content = document.createElement('div'); content.className = 'message-content';
    const meta = document.createElement('div'); meta.className = 'message-meta';
    const name = document.createElement('b'); name.textContent = Number(m.user_id) === cfg.userId ? 'You' : m.username;
    const time = document.createElement('time'); time.textContent = timeLabel(m.created_at);
    meta.append(name,time); const body = document.createElement('p'); body.className = 'bubble'; body.textContent = m.body;
    content.append(meta,body); row.append(avatar,content); messageList.append(row); lastMessageId = Math.max(lastMessageId, Number(m.id));
  };
  async function loadMessages(initial = false) {
    try { const data = await api('messages', null, 'GET', `&after=${initial ? 0 : lastMessageId}`); data.messages.forEach(addMessage); if (initial || data.messages.length) messageList.scrollTop = messageList.scrollHeight; }
    catch (e) { showNotice(e.message, true); }
  }
  $('message-form').addEventListener('submit', async (e) => {
    e.preventDefault(); const body = messageInput.value.trim(); if (!body) return;
    const button = $('message-form').querySelector('button'); button.disabled = true;
    try { await api('send_message', {body}, 'POST'); messageInput.value = ''; await loadMessages(false); }
    catch (err) { showNotice(err.message, true); }
    finally { button.disabled = false; messageInput.focus(); }
  });
  async function heartbeat() {
    try {
      const data = await api('heartbeat'); onlineUsers = data.users; const previousSelection = $('call-user').value;
      $('online-count').textContent = `${onlineUsers.length} online`;
      const list = $('member-list'), select = $('call-user'); list.innerHTML = ''; select.innerHTML = '<option value="">Select an online member</option>';
      onlineUsers.forEach(u => {
        const isMe = Number(u.id) === cfg.userId;
        const item = document.createElement('div'); item.className = 'member';
        const dot = document.createElement('i'); dot.className = 'presence-dot';
        const name = document.createElement('span'); name.textContent = u.username + (isMe ? ' (you)' : '');
        item.append(dot,name); list.append(item);
        if (!isMe) { const option = document.createElement('option'); option.value = u.id; option.textContent = u.username; select.append(option); }
      });
      if ([...select.options].some(o => o.value === previousSelection)) select.value = previousSelection;
      if (!onlineUsers.length) list.textContent = 'No active members';
      $('call-button').disabled = !select.value || Boolean(currentCallId);
    } catch (e) { /* transient hosting/network issue; next heartbeat retries */ }
  }
  $('call-user').addEventListener('change', () => { $('call-button').disabled = !$('call-user').value || Boolean(currentCallId); });
  const setCallStatus = (text) => { $('call-status').textContent = text; };
  const showHangup = (show) => $('hangup-call').classList.toggle('hidden', !show);
  function closePeer() { if (pc) { pc.onicecandidate = null; pc.ontrack = null; pc.close(); pc = null; } if (localStream) { localStream.getTracks().forEach(t => t.stop()); localStream = null; } $('remote-audio').srcObject = null; }
  function resetCall(text = 'No active call') { queuedLocalIce=[]; queuedRemoteIce=[]; closePeer(); currentCallId = null; currentCallPeer = null; pendingOffer = null; $('incoming-call').classList.add('hidden'); showHangup(false); setCallStatus(text); $('call-button').disabled = !$('call-user').value; }
  function makePeer(callId, peerName) {
    closePeer(); currentCallId = callId; currentCallPeer = peerName;
    pc = new RTCPeerConnection({iceServers: cfg.iceServers || []});
    pc.onicecandidate = (event) => { if (!event.candidate) return; if (currentCallId === 'pending') queuedLocalIce.push(event.candidate); else if (currentCallId) sendSignal('ice', event.candidate).catch(e => showNotice(e.message,true)); };
    pc.ontrack = (event) => { $('remote-audio').srcObject = event.streams[0]; };
    pc.onconnectionstatechange = () => {
      if (!pc) return;
      if (pc.connectionState === 'connected') setCallStatus(`Connected with ${currentCallPeer}`);
      if (['failed','disconnected'].includes(pc.connectionState)) setCallStatus('Connection interrupted. You can end the call and try again.');
    };
    return pc;
  }
  async function addMicrophone(peer) {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('Microphone access needs HTTPS and a supported browser.');
    const stream = await navigator.mediaDevices.getUserMedia({audio:true,video:false}); localStream = stream;
    stream.getTracks().forEach(track => peer.addTrack(track,stream));
  }
  async function sendSignal(type,payload=null) { if (!currentCallId || currentCallId==='pending') return; return api('call_signal',{call_id:currentCallId,type,payload},'POST'); }
  async function flushLocalIce() { const list=queuedLocalIce.splice(0); for (const candidate of list) await sendSignal('ice',candidate); }
  async function flushRemoteIce() { const list=queuedRemoteIce.splice(0); for (const candidate of list) { try { await pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch {} } }
  $('call-button').addEventListener('click', async () => {
    const to = Number($('call-user').value); if (!to) return;
    $('call-button').disabled = true; setCallStatus('Starting call…');
    try {
      const peer = makePeer('pending','Selected member'); await addMicrophone(peer);
      const offer = await peer.createOffer(); await peer.setLocalDescription(offer);
      const result = await api('call_start',{to_user_id:to,offer:peer.localDescription},'POST');
      currentCallId = result.call_id; currentCallPeer = result.target_name; await flushLocalIce(); setCallStatus(`Calling ${result.target_name}…`); showHangup(true);
    } catch(e) { resetCall('No active call'); showNotice(e.message,true); }
  });
  $('accept-call').addEventListener('click', async () => {
    if (!pendingOffer) return;
    const offer = pendingOffer; $('incoming-call').classList.add('hidden'); setCallStatus(`Connecting with ${offer.name}…`);
    try {
      const peer = makePeer(offer.call_id,offer.name); await addMicrophone(peer);
      await peer.setRemoteDescription(new RTCSessionDescription(offer.description)); await flushRemoteIce();
      const answer = await peer.createAnswer(); await peer.setLocalDescription(answer);
      await sendSignal('answer',peer.localDescription); showHangup(true); pendingOffer = null;
    } catch(e) { showNotice(e.message,true); try { await sendSignal('decline'); } catch {} resetCall('Call could not be accepted'); }
  });
  $('decline-call').addEventListener('click', async () => { try { if (pendingOffer) { currentCallId=pendingOffer.call_id; await sendSignal('decline'); } } catch {} resetCall('Call declined'); });
  $('hangup-call').addEventListener('click', async () => { try { await sendSignal('hangup'); } catch {} resetCall('Call ended'); });
  async function pollCalls() {
    if (callPollBusy) return; callPollBusy=true;
    try {
      const data = await api('call_poll',null,'GET',`&after=${lastSignalId}`);
      data.signals.forEach(async s => {
        lastSignalId=Math.max(lastSignalId,Number(s.id));
        if (s.signal_type==='offer') {
          const call = data.incoming.find(c => c.id===s.call_id);
          if (!currentCallId && call) { pendingOffer={call_id:s.call_id,name:call.from_name,description:s.payload}; $('incoming-name').textContent=call.from_name; $('incoming-call').classList.remove('hidden'); setCallStatus(`Incoming call from ${call.from_name}`); }
        } else if (s.signal_type==='answer' && currentCallId===s.call_id && pc) {
          try { await pc.setRemoteDescription(new RTCSessionDescription(s.payload)); await flushRemoteIce(); setCallStatus(`Connecting with ${currentCallPeer}…`); } catch(e) { showNotice('Could not connect the call.',true); }
        } else if (s.signal_type==='ice' && s.payload) {
          if (currentCallId===s.call_id && pc) { try { if (pc.remoteDescription) await pc.addIceCandidate(new RTCIceCandidate(s.payload)); else queuedRemoteIce.push(s.payload); } catch {} }
          else if (pendingOffer && pendingOffer.call_id===s.call_id) queuedRemoteIce.push(s.payload);
        } else if (['hangup','decline'].includes(s.signal_type) && currentCallId===s.call_id) resetCall(s.signal_type==='decline'?'Call declined':'Call ended by the other user');
      });
      if (data.active_call && currentCallId && data.active_call.id!==currentCallId) resetCall('Call status changed');
      if (!data.active_call && currentCallId && currentCallId!=='pending' && !pendingOffer) {
        // A call can have just been created; allow a short window for the next poll.
      }
    } catch(e) { /* retry on next cycle */ }
    finally { callPollBusy=false; }
  }
  loadMessages(true); heartbeat(); pollCalls();
  const interval = Math.max(2500, Number(cfg.pollInterval)||3000);
  setInterval(() => loadMessages(false), interval);
  setInterval(heartbeat, 20000);
  setInterval(pollCalls, 2200);
})();
